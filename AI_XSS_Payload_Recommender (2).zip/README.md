# AI-Based XSS Payload Recommender

## Overview
This tool uses OpenAI's GPT model to recommend XSS payloads based on input context or URL.

## Features
- Modern dark-themed UI
- Context-aware payload generation
- Secure input/output rendering
- Error handling for API quota limits

## Setup

```bash
pip install -r requirements.txt
python app.py
```

## Note
Make sure to add your own OpenAI API key in `app.py`. This is only for educational purposes.