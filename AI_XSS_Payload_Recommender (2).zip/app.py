from flask import Flask, request, render_template
from openai import OpenAI

app = Flask(__name__)

client = OpenAI(api_key="sk-REPLACE-WITH-YOUR-KEY")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    context = request.form['context']

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an expert in web security and XSS attack payloads."},
                {"role": "user", "content": f"Suggest 5 XSS payloads for the following context: {context}"}
            ],
            max_tokens=200,
            temperature=0.7
        )
        text_response = response.choices[0].message.content.strip()
        suggestions = text_response.split("\n")

    except Exception as e:
        suggestions = [f"Error: {e}"]

    return render_template('index.html', suggestions=suggestions, context=context)

if __name__ == '__main__':
    app.run(debug=True)